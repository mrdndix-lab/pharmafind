# PharmaFind

A local pharmacy price/stock comparison platform: customers search for a
medicine by brand name, generic name, or how they feel; pharmacies manage
their own stock through a login dashboard.

This package has two parts:

- **Interactive prototype** (published separately as a live artifact) — the
  full user experience: search, comparison, pharmacy dashboard, privacy/terms
  pages, cookie banner, 404. It runs entirely in the browser (no server) so
  you can click through it and share the link immediately.
- **Backend** (this folder) — a real Flask + SQLite API with actual password
  hashing, server-side sessions, and validation. This is what a production
  frontend would call instead of the prototype's in-browser simulation.

## Why two versions

The prototype simulates accounts and stock with your browser's local
storage, so it works instantly for anyone with the link and needs nothing
installed. That's great for demos but isn't real multi-device data. The
backend here is the genuine implementation — run it, point a real frontend
at it, and you have actual accounts and a shared database.

## Running the backend locally

```bash
cd backend
pip install -r requirements.txt
python app.py
# -> http://localhost:5000
```

Try it:

```bash
curl http://localhost:5000/api/health
curl http://localhost:5000/api/medications
curl -X POST http://localhost:5000/api/pharmacies/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test Pharmacy","email":"you@example.com","password":"supersecret123"}'
```

## API summary

| Endpoint | Method | Notes |
|---|---|---|
| `/api/health` | GET | Uptime check |
| `/api/medications` | GET | Full medicine catalog |
| `/api/search?q=` | GET | Cross-pharmacy search, cheapest in-stock first |
| `/api/pharmacies/register` | POST | `name`, `email`, `password` (8+ chars), `area`, `phone` |
| `/api/pharmacies/login` | POST | `email`, `password` — sets a session cookie |
| `/api/pharmacies/logout` | POST | Clears the session |
| `/api/pharmacies/me` | GET | Current session's pharmacy, if any |
| `/api/inventory` | GET/POST | List / add-or-update a stock line (auth required) |
| `/api/inventory/<id>` | DELETE | Remove a stock line (auth required) |

Search understands medicine names, brand names, common typos, and a built-in
symptom dictionary ("headache" → pain relief). For free-text descriptions it
doesn't recognize, `ai_suggest_categories()` in `app.py` will call Claude if
you set `ANTHROPIC_API_KEY` (see `env.example`) — entirely optional, and the
endpoint works normally without it.

## Path to production

What's already handled in the code here, and what's still on you:

**Done in this code:**
- Password hashing (werkzeug), server-side sessions, parameterized SQL
- Input validation on every endpoint (email format, password length, price/stock bounds)
- Honeypot spam field on registration (`hp_token` — must match the frontend's hidden field)
- Security response headers (`X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy`, HSTS) set on every response
- An HTTPS-required check for when you're behind a proxy (`FORCE_HTTPS=1`)
- A Dockerfile that serves with gunicorn instead of Flask's dev server

**Still needed from you:**
1. **A real `SECRET_KEY`.** Generate one (`python3 -c "import secrets; print(secrets.token_hex(32))"`) and set it as an environment variable — never commit it.
2. **HTTPS.** This app enforces HTTPS at the application layer, but a TLS certificate itself comes from your host or a reverse proxy — Render, Railway, Fly.io, a VPS behind Caddy/nginx, or a CDN like Cloudflare all issue one automatically once you add your domain. See `config/nginx-security-headers.conf` and `config/_headers` for two ready-made examples.
3. **Move off SQLite** once you have concurrent writers at scale — Postgres is the usual next step; the queries here are plain SQL and port over directly.
4. **Rate limiting** on `/api/pharmacies/login` and `/api/pharmacies/register` (Flask-Limiter is the standard choice) to slow down credential-stuffing and spam beyond what the honeypot catches.
5. **CAPTCHA** (hCaptcha or Cloudflare Turnstile) if spam gets past the honeypot in practice — the honeypot stops simple bots; a determined one won't be.
6. **Real analytics.** Google Analytics/Plausible only start working once this is live on your own domain — this environment's preview sandbox blocks third-party analytics scripts by policy, so nothing is wired into the prototype.
7. **Legal review.** The Privacy Policy and Terms in the prototype are solid starting templates, not legal advice — have a lawyer check them against the laws of wherever you're actually operating, and fill in your real contact details and governing jurisdiction.
8. **A real Open Graph image.** `assets/og-banner.svg` is a ready design — export it to a 1200×630 PNG (any design tool, or an online SVG-to-PNG converter) and host it at the URL your `og:image` tag points to.
9. **Wire the real frontend to this API.** Once you deploy both, replace the prototype's `localStorage` calls with `fetch()` calls to these endpoints (`credentials: 'include'` so the session cookie is sent), and set `ALLOWED_ORIGINS` here to your frontend's exact domain.

## Files in this bundle

```
backend/        Flask API (app.py), requirements.txt, Dockerfile, env.example
config/         sitemap.xml, robots.txt, and two security-headers examples (Netlify-style + nginx)
assets/         Social preview banner (SVG)
```

The interactive prototype itself is published as its own artifact — see the
link shared alongside this bundle.
